﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LadingPro.ladingPro
{
    class contactClass
    {
        //Getter Setter Properties
        //Acts as data carrier in our application
        public string ExportDetails { get; set; }
        public string ConsignDetails { get; set; }
        public string NotifName { get; set; }
        public string BookingNo { get; set; }
        public string LadingNo { get; set; }
        public string ExportRef { get; set; }
        public string DestAgent { get; set; }
        public string LoadTerm { get; set; }
        public string TypeMove { get; set; }
        public string FreightCharge { get; set; }
        public string Prepaid { get; set; }
        public string Collect { get; set; }
        public string TotalCharge { get; set; }
        public string PreCar { get; set; }
        public string PlaceRec { get; set; }
        public string ExportCar { get; set; }
        public string PortLoad { get; set; }
        public string PortDisch { get; set; }
        public string PlaceDel { get; set; }
        public string MarksNum { get; set; }
        public string NumPackage { get; set; }
        public string DescPack { get; set; }
        public string GrossWeight { get; set; }
        public string Measurement { get; set; }

        static string myconnstrng = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;

        //Selecting Data from Database
        public DataTable Select()
        {
            //Step 1: Database connection
            SqlConnection conn = new SqlConnection(myconnstrng);
            DataTable dt = new DataTable();
            try
            {
                //Step 2: Writing SQL Query
                string sql = "SELECT * FROM tbl_contacts";
                //Creating cmd using sql and conn
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Creating SQL Data Adapter using cmd
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                conn.Open();
                adapter.Fill(dt);
            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return dt;
        }

        //Inserting Data into database
        public bool Insert(contactClass c)
        {
            //Creating a default return type and setting its value to false
            bool isSuccess = false;

            //Step 1: Connect Database
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                //Step 2: Create a SQL Query to insert Data
                string sql = "INSERT INTO tbl_contacts (ExportDetails, ConsignDetails, NotifName, BookingNo, LadingNo, ExportRef, DestAgent, LoadTerm, TypeMove, FreightCharge, Prepaid, Collect, TotalCharge, PreCar, PlaceRec, ExportCar, PortLoad, PortDisch, PlaceDel, MarksNum, NumPackage, DescPack, GrossWeight, Measurement) VALUES (@ExportDetails, @ConsignDetails, @NotifName, @BookingNo, @LadingNo, @ExportRef, @DestAgen, @LoadTerm, @TypeMove, @FreightCharge, @Prepaid, @Collect, @TotalCharge, @PreCar, @PlaceRec, @ExportCar, @PortLoad, @PortDisch, @PlaceDel, @MarksNum, @NumPackage, @DescPack, @GrossWeight, @Measurement)";
                //Creating SQL command using sql and conn
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Create parameters to add data
                cmd.Parameters.AddWithValue("@ExportDetails", c.ExportDetails);
                cmd.Parameters.AddWithValue("@ConsignDetails", c.ConsignDetails);
                cmd.Parameters.AddWithValue("@NotifName", c.NotifName);
                cmd.Parameters.AddWithValue("@BookingNo", c.BookingNo);
                cmd.Parameters.AddWithValue("@LadingNo", c.LadingNo);
                cmd.Parameters.AddWithValue("@ExportRef", c.ExportRef);
                cmd.Parameters.AddWithValue("@DestAgen", c.DestAgent);
                cmd.Parameters.AddWithValue("@LoadTerm", c.LoadTerm);
                cmd.Parameters.AddWithValue("@TypeMove", c.TypeMove);
                cmd.Parameters.AddWithValue("@FreightCharge", c.FreightCharge);
                cmd.Parameters.AddWithValue("@Prepaid", c.Prepaid);
                cmd.Parameters.AddWithValue("@Collect", c.Collect);
                cmd.Parameters.AddWithValue("@TotalCharge", c.TotalCharge);
                cmd.Parameters.AddWithValue("@PreCar", c.PreCar);
                cmd.Parameters.AddWithValue("@PlaceRec", c.PlaceRec);
                cmd.Parameters.AddWithValue("@ExportCar", c.ExportCar);
                cmd.Parameters.AddWithValue("@PortLoad", c.PortLoad);
                cmd.Parameters.AddWithValue("@PortDisch", c.PortDisch);
                cmd.Parameters.AddWithValue("@PlaceDel", c.PlaceDel);
                cmd.Parameters.AddWithValue("@MarksNum", c.MarksNum);
                cmd.Parameters.AddWithValue("@NumPackage", c.NumPackage);
                cmd.Parameters.AddWithValue("@DescPack", c.DescPack);
                cmd.Parameters.AddWithValue("@GrossWeight", c.GrossWeight);
                cmd.Parameters.AddWithValue("@Measurement", c.Measurement);

                //Connection Open
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                //If query is successful then values of rows is more than zero else it will be 0
                if(rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }

        //Method to update data in database from our app
        public bool Update(contactClass c)
        {
            //Create a default return type and set its value to false
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                //SQL to update data in our database
                string sql = "UPDATE tbl_contacts SET ExportDetails=@ExportDetails, ConsignDetails=@ConsignDetails, NotifName=@NotifName, LadingNo=@LadingNo, ExportRef=@ExportRef, DestAgent=@DestAgen, LoadTerm=@LoadTerm, TypeMove=@TypeMove, FreightCharge=@FreightCharge, Prepaid=@Prepaid, Collect=@Collect, TotalCharge=@TotalCharge, PreCar=@PreCar, PlaceRec=@PlaceRec, ExportCar=@ExportCar, PortLoad=@PortLoad, PortDisch=@PortDisch, PlaceDel=@PlaceDel, MarksNum=@MarksNum, NumPackage=@NumPackage, DescPack=@DescPack, GrossWeight=@GrossWeight, Measurement=@Measurement WHERE BookingNo=@BookingNo";
                //Creating SQL command
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Create parameters to add values
                cmd.Parameters.AddWithValue("@ExportDetails", c.ExportDetails);
                cmd.Parameters.AddWithValue("@ConsignDetails", c.ConsignDetails);
                cmd.Parameters.AddWithValue("@NotifName", c.NotifName);
                cmd.Parameters.AddWithValue("@BookingNo", c.BookingNo);
                cmd.Parameters.AddWithValue("@LadingNo", c.LadingNo);
                cmd.Parameters.AddWithValue("@ExportRef", c.ExportRef);
                cmd.Parameters.AddWithValue("@DestAgen", c.DestAgent);
                cmd.Parameters.AddWithValue("@LoadTerm", c.LoadTerm);
                cmd.Parameters.AddWithValue("@TypeMove", c.TypeMove);
                cmd.Parameters.AddWithValue("@FreightCharge", c.FreightCharge);
                cmd.Parameters.AddWithValue("@Prepaid", c.Prepaid);
                cmd.Parameters.AddWithValue("@Collect", c.Collect);
                cmd.Parameters.AddWithValue("@TotalCharge", c.TotalCharge);
                cmd.Parameters.AddWithValue("@PreCar", c.PreCar);
                cmd.Parameters.AddWithValue("@PlaceRec", c.PlaceRec);
                cmd.Parameters.AddWithValue("@ExportCar", c.ExportCar);
                cmd.Parameters.AddWithValue("@PortLoad", c.PortLoad);
                cmd.Parameters.AddWithValue("@PortDisch", c.PortDisch);
                cmd.Parameters.AddWithValue("@PlaceDel", c.PlaceDel);
                cmd.Parameters.AddWithValue("@MarksNum", c.MarksNum);
                cmd.Parameters.AddWithValue("@NumPackage", c.NumPackage);
                cmd.Parameters.AddWithValue("@DescPack", c.DescPack);
                cmd.Parameters.AddWithValue("@GrossWeight", c.GrossWeight);
                cmd.Parameters.AddWithValue("@Measurement", c.Measurement);
                //Open Database connection
                conn.Open();

                int rows = cmd.ExecuteNonQuery();
                //If the query runs successfully then the value of rows will be greater than zero else it will be 0
                if(rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                conn.Close();
            }
            return isSuccess;
        }
        //Method to delete from database
        public bool Delete(contactClass c)
        {
            //Create a default return type and set value to false
            bool isSuccess = false;
            //Create sql conection
            SqlConnection conn = new SqlConnection(myconnstrng);
            try
            {
                //SQL to delete data
                string sql = "DELETE FROM tbl_contacts WHERE BookingNo=@BookingNo";

                //Creating SQL Command
                SqlCommand cmd = new SqlCommand(sql, conn);
                //Open connection
                conn.Open();
                int rows = cmd.ExecuteNonQuery();
                //If query is successful then values of rows is greater than 0 else it is 0
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch(Exception ex)
            {

            }
            finally
            {
                //Close connection
                conn.Close();
            }
            return isSuccess;
        }
    }
}
