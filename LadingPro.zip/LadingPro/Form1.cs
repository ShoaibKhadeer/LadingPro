﻿using LadingPro.ladingPro;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LadingPro
{
    public partial class LadingPro : Form
    {
        public LadingPro()
        {
            InitializeComponent();
        }
        contactClass c = new contactClass();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAddClick(object sender, EventArgs e)
        {
            //Get value of from the input fields
            c.ExportDetails = textBox1.Text;
            c.ConsignDetails = textBox2.Text;
            c.NotifName = textBox3.Text;
            c.BookingNo = textBox4.Text;
            c.LadingNo = textBox5.Text;
            c.ExportRef = textBox6.Text;
            c.DestAgent = textBox7.Text;
            c.LoadTerm = textBox8.Text;
            c.TypeMove = textBox9.Text;
            c.FreightCharge = textBox16.Text;
            c.Prepaid = textBox17.Text;
            c.Collect = textBox18.Text;
            c.TotalCharge = textBox19.Text;
            c.PreCar = textBox10.Text;
            c.PlaceRec = textBox11.Text;
            c.ExportCar = textBox12.Text;
            c.PortLoad = textBox13.Text;
            c.PortDisch = textBox14.Text;
            c.PlaceDel = textBox15.Text;
            c.MarksNum = textBox20.Text;
            c.NumPackage = textBox21.Text;
            c.DescPack = textBox22.Text;
            c.GrossWeight = textBox23.Text;
            c.Measurement = textBox24.Text;

            //Insert data into database using contactClass.cs
            bool success = c.Insert(c);
            if (success == true)
            {
                //Successful insertion
                MessageBox.Show("Successfully Added");
            }
            else
            {
                //Failed
                MessageBox.Show("Error! Please check values and try again.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Get value of from the input fields
            c.ExportDetails = textBox1.Text;
            c.ConsignDetails = textBox2.Text;
            c.NotifName = textBox3.Text;
            c.BookingNo = textBox4.Text;
            c.LadingNo = textBox5.Text;
            c.ExportRef = textBox6.Text;
            c.DestAgent = textBox7.Text;
            c.LoadTerm = textBox8.Text;
            c.TypeMove = textBox9.Text;
            c.FreightCharge = textBox16.Text;
            c.Prepaid = textBox17.Text;
            c.Collect = textBox18.Text;
            c.TotalCharge = textBox19.Text;
            c.PreCar = textBox10.Text;
            c.PlaceRec = textBox11.Text;
            c.ExportCar = textBox12.Text;
            c.PortLoad = textBox13.Text;
            c.PortDisch = textBox14.Text;
            c.PlaceDel = textBox15.Text;
            c.MarksNum = textBox20.Text;
            c.NumPackage = textBox21.Text;
            c.DescPack = textBox22.Text;
            c.GrossWeight = textBox23.Text;
            c.Measurement = textBox24.Text;

            //Insert data into database using contactClass.cs
            bool success = c.Insert(c);
            if (success == true)
            {
                //Successful insertion
                MessageBox.Show("Successfully Added");
                //Call the Clear method
                Clear();
                //Load the data on data gridview
                DataTable dt = c.Select();
                dataGridView1.DataSource = dt;
            }
            else
            {
                //Failed
                MessageBox.Show("Error! Please check values and try again.");
            }
        }

        private void LadingPro_Load(object sender, EventArgs e)
        {
            //Load the data on data gridview
            DataTable dt = c.Select();
            dataGridView1.DataSource = dt;
        }
        
        //Method to clear the fields
        public void Clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox16.Text = "";
            textBox17.Text = "";
            textBox18.Text = "";
            textBox19.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            textBox14.Text = "";
            textBox15.Text = "";
            textBox20.Text = "";
            textBox21.Text = "";
            textBox22.Text = "";
            textBox23.Text = "";
            textBox24.Text = "";
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //Get the data from the data grid and load it in the form
            //Identify the row where the mouse was clicked
            int RowIndex = e.RowIndex;
            textBox1.Text = dataGridView1.Rows[RowIndex].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[RowIndex].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[RowIndex].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[RowIndex].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[RowIndex].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.Rows[RowIndex].Cells[5].Value.ToString();
            textBox7.Text = dataGridView1.Rows[RowIndex].Cells[6].Value.ToString();
            textBox8.Text = dataGridView1.Rows[RowIndex].Cells[7].Value.ToString();
            textBox9.Text = dataGridView1.Rows[RowIndex].Cells[8].Value.ToString();
            textBox16.Text = dataGridView1.Rows[RowIndex].Cells[15].Value.ToString();
            textBox17.Text = dataGridView1.Rows[RowIndex].Cells[16].Value.ToString();
            textBox18.Text = dataGridView1.Rows[RowIndex].Cells[17].Value.ToString();
            textBox19.Text = dataGridView1.Rows[RowIndex].Cells[18].Value.ToString();
            textBox10.Text = dataGridView1.Rows[RowIndex].Cells[9].Value.ToString();
            textBox11.Text = dataGridView1.Rows[RowIndex].Cells[10].Value.ToString();
            textBox12.Text = dataGridView1.Rows[RowIndex].Cells[11].Value.ToString();
            textBox13.Text = dataGridView1.Rows[RowIndex].Cells[12].Value.ToString();
            textBox14.Text = dataGridView1.Rows[RowIndex].Cells[13].Value.ToString();
            textBox15.Text = dataGridView1.Rows[RowIndex].Cells[14].Value.ToString();
            textBox20.Text = dataGridView1.Rows[RowIndex].Cells[19].Value.ToString();
            textBox21.Text = dataGridView1.Rows[RowIndex].Cells[20].Value.ToString();
            textBox22.Text = dataGridView1.Rows[RowIndex].Cells[21].Value.ToString();
            textBox23.Text = dataGridView1.Rows[RowIndex].Cells[22].Value.ToString();
            textBox24.Text = dataGridView1.Rows[RowIndex].Cells[23].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Get data from textbox 
            c.ExportDetails = textBox1.Text;
            c.ConsignDetails = textBox2.Text;
            c.NotifName = textBox3.Text;
            c.BookingNo = textBox4.Text;
            c.LadingNo = textBox5.Text;
            c.ExportRef = textBox6.Text;
            c.DestAgent = textBox7.Text;
            c.LoadTerm = textBox8.Text;
            c.TypeMove = textBox9.Text;
            c.FreightCharge = textBox16.Text;
            c.Prepaid = textBox17.Text;
            c.Collect = textBox18.Text;
            c.TotalCharge = textBox19.Text;
            c.PreCar = textBox10.Text;
            c.PlaceRec = textBox11.Text;
            c.ExportCar = textBox12.Text;
            c.PortLoad = textBox13.Text;
            c.PortDisch = textBox14.Text;
            c.PlaceDel = textBox15.Text;
            c.MarksNum = textBox20.Text;
            c.NumPackage = textBox21.Text;
            c.DescPack = textBox22.Text;
            c.GrossWeight = textBox23.Text;
            c.Measurement = textBox24.Text;
            //Update data in database
            bool success = c.Update(c);
            if (success == true)
            {
                //Update was successful
                MessageBox.Show("Form has been updated.");
                //Load the data on data gridview
                DataTable dt = c.Select();
                dataGridView1.DataSource = dt;
            }
            else
            {
                //Update failed
                MessageBox.Show("ERROR: Form failed to update.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Get contactID from application
            c.BookingNo = textBox4.Text;
            bool success = c.Delete(c);
            if(success == true)
            {
                //Deletion successful
                MessageBox.Show("Form Successfully deleted.");
            }
            else
            {
                MessageBox.Show("ERROR: Failed to delete form.");
            }
        }

        static string myconnstr = ConfigurationManager.ConnectionStrings["connstrng"].ConnectionString;
        private void textBox25_TextChanged(object sender, EventArgs e)
        {
            //Get the value from the text box
            string keyword = textBox25.Text;
            SqlConnection conn = new SqlConnection(myconnstr);
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tbl_contacts WHERE ExportDetails LIKE '%"+keyword+"%' OR ConsignDetails LIKE '%"+keyword+"%'", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
